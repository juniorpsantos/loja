Changelog
=========

Version 1.1.2 (2023-08-24)
--------------------------
* Refactor: Improved code optimization and organization

Version 1.1.1 (2023-08-04)
--------------------------
* Updated API base routes
* Code refactored for optimization and security
* Compatibility with PHP >= 7.2

Version 1.1.0 (2023-05-18)
--------------------------
* Refactored code
* Added functionality that reuses the auth access token


Version 1.0.1 (2023-02-14)
--------------------------
* Added new examples of Pix split


Version 1.0.0 (2023-01-31)
--------------------------
* Initial release